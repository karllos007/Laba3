package com.example.infohunter

data class ListItem (
    var image_id:Int,
    var titleText:String,
    var contentText:String
        )