package com.example.infohunter


import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.DialogTitle
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.main_content.*


class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    var adapter: MyAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nav_view.setNavigationItemSelectedListener (this)
        var list = ArrayList<ListItem>()

        list.addAll(fillArras(resources.getStringArray(R.array.animals),resources.getStringArray(R.array.animals_content), getImageId(R.array.animals_image_array)))
        rcView.hasFixedSize()
        rcView.layoutManager = LinearLayoutManager(this)

        rcView.adapter = MyAdapter(list, this)
        adapter = MyAdapter(list, this)
        rcView.adapter=adapter

    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.id_animals -> {
                adapter?.updateAdapter(fillArras(resources.getStringArray(R.array.animals),resources.getStringArray(R.array.animals_content), getImageId(R.array.animals_image_array)))
                Toast.makeText(this,"Id animals", Toast.LENGTH_SHORT).show()
            }
            R.id.id_guns -> {
                adapter?.updateAdapter(fillArras(resources.getStringArray(R.array.guns),resources.getStringArray(R.array.guns_content), getImageId(R.array.guns_image_array)))
                Toast.makeText(this,"Id guns", Toast.LENGTH_SHORT).show()
            }
            R.id.id_clothes -> {
                adapter?.updateAdapter(fillArras(resources.getStringArray(R.array.clothes),resources.getStringArray(R.array.clothes_content), getImageId(R.array.clothes_image_array)))
                Toast.makeText(this,"Id clothes", Toast.LENGTH_SHORT).show()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)

        return true
    }

    fun fillArras(titleArray: Array<String>,contentArray: Array<String>,imageArray: IntArray):List<ListItem>
    {
        var listItemArray = ArrayList<ListItem>()
        for (n in 0..titleArray.size - 1)
        {
            var listItem = ListItem(imageArray[n],titleArray[n],contentArray[n])
            listItemArray.add(listItem)
        }
        return listItemArray

    }
    fun getImageId(imageArrayId:Int):IntArray
    {
        var tArray: TypedArray = resources.obtainTypedArray(imageArrayId)
        var count = tArray.length()
        var ids = IntArray(count)
        for (i in ids.indices){
            ids[i] = tArray.getResourceId(i,0)
        }
        tArray.recycle()
        return ids
    }
}